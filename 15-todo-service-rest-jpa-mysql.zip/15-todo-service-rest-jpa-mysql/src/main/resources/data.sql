INSERT INTO TODOS (id , username , description , target_date , is_done)
VALUES
(1, 'Tatha', 'Learn Spring Boot', CURRENT_TIMESTAMP(), false);

INSERT INTO TODOS (id , username , description , target_date , is_done)
VALUES
(2, 'Tatha', 'Learn Azure Fundamentals', CURRENT_TIMESTAMP(), false);

INSERT INTO TODOS (id , username , description , target_date , is_done)
VALUES
(3, 'Tatha', 'Learn Java 11', CURRENT_TIMESTAMP(), false);
