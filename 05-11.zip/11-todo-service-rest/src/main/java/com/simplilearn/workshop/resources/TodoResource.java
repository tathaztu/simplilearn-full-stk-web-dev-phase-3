package com.simplilearn.workshop.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.simplilearn.workshop.domain.Todo;
import com.simplilearn.workshop.service.TodoService;

@RestController
public class TodoResource {

	@Autowired
	private TodoService todoService;

	// HTTP Method: GET
	// URI: /users/vinodh/todos

	@GetMapping(path="/users/{username}/todos")
	public List<Todo> getAllTodos(@PathVariable String username){
		return todoService.findAll();
	}

	// HTTP Method: GET
	// URI: /users/vinodh/1

	@GetMapping(path="/users/{username}/{id}")
	public Todo getTodo(@PathVariable String username, @PathVariable Integer id){
		return todoService.findById(id);
	}

}
