INSERT INTO TODOS (id , username , description , targetdate , isdone )
VALUES
(1, 'Tatha', 'Learn Spring', CURRENT_TIMESTAMP(), false);

INSERT INTO TODOS (id , username , description , targetdate , isdone )
VALUES
(2, 'Tatha', 'Learn Azure', CURRENT_TIMESTAMP(), false);

INSERT INTO TODOS (id , username , description , targetdate , isdone )
VALUES
(3, 'Tatha', 'Learn Hibernate', CURRENT_TIMESTAMP(), false);
