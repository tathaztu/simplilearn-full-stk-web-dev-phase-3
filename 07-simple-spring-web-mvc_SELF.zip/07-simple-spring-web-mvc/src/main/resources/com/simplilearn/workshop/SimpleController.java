package com.simplilearn.workshop;

public class SimpleController {

}
